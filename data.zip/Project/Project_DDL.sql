CREATE DATABASE IF NOT EXISTS project;  
USE project;  

-- Create USER table
CREATE TABLE USER (
    UserID INT PRIMARY KEY,
    userName VARCHAR(255),
    userEmailID VARCHAR(255),
    userAddress VARCHAR(255),
    City VARCHAR(255),
    State VARCHAR(255),
    zipCode VARCHAR(10),
    userPhoneNr VARCHAR(20),
    UserType VARCHAR(50)
);

-- Create DRIVER table
CREATE TABLE DRIVER (
    DriverID INT PRIMARY KEY,
    name VARCHAR(255),
    licenseNr VARCHAR(50),
    shiftDay VARCHAR(50),
    location VARCHAR(255)
);

-- Create VEHICLE table
CREATE TABLE VEHICLE (
    VinNr VARCHAR(50) PRIMARY KEY,
    maek VARCHAR(255),
    model VARCHAR(255),
    Year INT,
    Loc VARCHAR(255)
);

-- Create Route table
CREATE TABLE Route (
    RouteID INT PRIMARY KEY,
    startLoc VARCHAR(255),
    EndLoc VARCHAR(255),
    Stop1 VARCHAR(255),
    Stop2 VARCHAR(255),
    Stop3 VARCHAR(255),
    Stop4 VARCHAR(255),
    Stop5 VARCHAR(255),
    Distance FLOAT
);

-- Create Delivery table
CREATE TABLE Delivery (
    RouteID INT,
    VinNr VARCHAR(50),
    DriverID INT,
    FOREIGN KEY (RouteID) REFERENCES Route(RouteID),
    FOREIGN KEY (VinNr) REFERENCES VEHICLE(VinNr),
    FOREIGN KEY (DriverID) REFERENCES DRIVER(DriverID)
);

-- Create PRODUCT table
CREATE TABLE PRODUCT (
    ProductID INT PRIMARY KEY,
    name VARCHAR(255),
    price DECIMAL(10,2),
    category VARCHAR(255),
    expiryDate DATE
);

-- Create SUPPLIER table
CREATE TABLE SUPPLIER (
    SupplierID INT PRIMARY KEY,
    VAT VARCHAR(50),
    name VARCHAR(255),
    phoneNr VARCHAR(20),
    address VARCHAR(255),
    email VARCHAR(255)
);

-- Create SUPPLY table
CREATE TABLE SUPPLY (
    SupplierID INT,
    ProductID INT,
    FOREIGN KEY (SupplierID) REFERENCES SUPPLIER(SupplierID),
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID)
);

-- Create Warehouse table
CREATE TABLE Warehouse (
    WarehosueID INT PRIMARY KEY,
    Location VARCHAR(255),
    Capacity INT
);

-- Create INVENTORY table
CREATE TABLE INVENTORY (
    WarehosueID INT,
    ProductID INT,
    quantityInStock INT,
    PRIMARY KEY (WarehosueID, ProductID),
    FOREIGN KEY (WarehosueID) REFERENCES Warehouse(WarehosueID),
    FOREIGN KEY (ProductID) REFERENCES PRODUCT(ProductID)
);

-- Create PROMOTION table
CREATE TABLE PROMOTION (
    PromotionID INT PRIMARY KEY,
    name VARCHAR(255),
    description TEXT,
    VaildFrom DATE,
    VaildTo DATE
);

-- Create ORDERS table
CREATE TABLE ORDERS (
    OrderID INT PRIMARY KEY,
    productID INT,
    amount INT,
    orderStatus VARCHAR(50),
    orderDate DATE,
    RouteID INT,
    WarehosueID INT,
    PromotionID INT,
    FOREIGN KEY (productID) REFERENCES PRODUCT(ProductID),
    FOREIGN KEY (RouteID) REFERENCES Route(RouteID),
    FOREIGN KEY (WarehosueID) REFERENCES Warehouse(WarehosueID),
    FOREIGN KEY (PromotionID) REFERENCES PROMOTION(PromotionID)
);

-- Create SUBSCRIPTION table
CREATE TABLE SUBSCRIPTION (
    SubID INT PRIMARY KEY,
    startDate DATE,
    endDate DATE,
    frequency VARCHAR(50),
    status VARCHAR(50),
    UserID INT,
    OrderID INT,
    FOREIGN KEY (UserID) REFERENCES USER(UserID),
    FOREIGN KEY (OrderID) REFERENCES ORDERS(OrderID)
);

-- Create EXTRA_ITEM table
CREATE TABLE EXTRA_ITEM (
    UserID INT,
    OrderID INT,
    productID INT,
    quanlity INT,
    FOREIGN KEY (UserID) REFERENCES USER(UserID),
    FOREIGN KEY (OrderID) REFERENCES ORDERS(OrderID),
    FOREIGN KEY (productID) REFERENCES PRODUCT(ProductID)
);

-- Create FEEDBACK table
CREATE TABLE FEEDBACK (
    fbID INT PRIMARY KEY,
    rating INT,
    comments TEXT,
    date DATE,
    UserID INT,
    OrderID INT,
    FOREIGN KEY (UserID) REFERENCES USER(UserID),
    FOREIGN KEY (OrderID) REFERENCES ORDERS(OrderID)
);

-- Create PAYMENT table
CREATE TABLE PAYMENT (
    PayNr INT PRIMARY KEY,
    DueDate DATE,
    amount DECIMAL(10,2),
    OrderID INT,
    FOREIGN KEY (OrderID) REFERENCES ORDERS(OrderID)
);
